const registerForm = document.getElementById('registerForm');
const secretCodeDiv = document.getElementById('secretCode');
const codeP = document.getElementById('code');
const loginForm = document.getElementById('loginForm');
const registerView = document.getElementById('registerView');
const loginView = document.getElementById('loginView');
const showLogin = document.getElementById('showLogin');
const showRegister = document.getElementById('showRegister');

showLogin.addEventListener('click', (e) => {
    e.preventDefault();
    registerView.style.display = 'none';
    loginView.style.display = 'block';
});

showRegister.addEventListener('click', (e) => {
    e.preventDefault();
    loginView.style.display = 'none';
    registerView.style.display = 'block';
});


registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const response = await fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name })
    });
    const data = await response.json();
    if (response.ok) {
        registerForm.style.display = 'none';
        secretCodeDiv.style.display = 'block';
        codeP.textContent = data.secretCode;
    } else {
        alert(data.message);
    }
});

async function loadAdminPanel() {
    const response = await fetch('/users');
    const users = await response.json();
    const unapprovedUsersList = document.getElementById('unapprovedUsers');
    unapprovedUsersList.innerHTML = '';
    users.forEach(user => {
        if (!user.isApproved) {
            const li = document.createElement('li');
            li.textContent = user.name;
            const approveButton = document.createElement('button');
            approveButton.textContent = 'Approve';
            approveButton.onclick = () => approveUser(user.name);
            li.appendChild(approveButton);
            unapprovedUsersList.appendChild(li);
        }
    });
}

async function approveUser(name) {
    const response = await fetch('/approve', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name })
    });
    if (response.ok) {
        loadAdminPanel();
    } else {
        const data = await response.json();
        alert(data.message);
    }
}

const makeAdminForm = document.getElementById('makeAdminForm');
makeAdminForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const secretCode = document.getElementById('adminName').value;
    const response = await fetch('/makeAdmin', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ secretCode })
    });
    if (response.ok) {
        alert('User is now an admin');
        document.getElementById('adminName').value = '';
    } else {
        const data = await response.json();
        alert(data.message);
    }
});

const quizQuestions = [
    "ვინ მოიგონა ყავა",
    "რა არის კვანტური სიმღერა",
    "რამდენი დრო არსებობს",
    "რა არის ვექტორი",
    "რა არის ბერმუდის სამკუთხედის ცენტრში",
    "რამდენად რასისტია ლუკა",
    "ხარ თუ არა ზანგი",
    "რამდენი დრო გაქვთ გატარებული ამ კლაშსი",
    "რა არის ალეგორია",
    "რამდენჯერ გაიჭედა გეგა ტუალეტიში",
    "რამდენი ხანი ჰქონდა დოლიძეს გაჭედილი თითი მერხში",
    "რომელი საუკუნეა",
    "რამდენჯერ გააკუა დოლიძემ",
    "ვინ თქვა ფრაზა ,,მე ვიცი რომ არაფერ არ ვიცი\"",
    "ვინ არის ფიზიკოსი ამ კლაშსი",
    "ვინ იყო მართალი შოპენჰაუერი თუ ნიცშე",
    "რა ერქვა რომის იმპერატორს იულიუს კეისარს",
    "რამდენი ბავშვია კლაშსი",
    "ვინ თქვა ფრაზა ,,თუ ყველაფერის სწავლა არ გინდა, სიყვარული ისწავლე\""
];

function loadQuiz() {
    const quizForm = document.getElementById('quizForm');
    quizQuestions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.innerHTML = `
            <label for="q${index}">${question}</label>
            <input type="text" id="q${index}" name="q${index}" required>
        `;
        quizForm.appendChild(questionDiv);
    });
}

window.addEventListener('load', loadQuiz);

const submitQuizButton = document.getElementById('submitQuiz');
submitQuizButton.addEventListener('click', async () => {
    const answers = [];
    quizQuestions.forEach((_, index) => {
        answers.push(document.getElementById(`q${index}`).value);
    });

    const name = document.getElementById('loginName').value;
    const response = await fetch('/submitQuiz', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, answers })
    });
    const data = await response.json();
    if (response.ok) {
        document.getElementById('quizForm').style.display = 'none';
        submitQuizButton.style.display = 'none';
        document.getElementById('publicCode').style.display = 'block';
        document.getElementById('pCode').textContent = data.publicCode;
    } else {
        alert(data.message);
    }
});

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const loginName = document.getElementById('loginName').value;
    const loginCode = document.getElementById('loginCode').value;
    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ loginName, loginCode })
    });
    const data = await response.json();
    if (response.ok) {
        document.getElementById('authContainer').style.display = 'none';
        if (data.isAdmin) {
            document.getElementById('adminContainer').style.display = 'block';
            loadAdminPanel();
        } else {
            document.getElementById('quizContainer').style.display = 'block';
        }
    } else {
        alert(data.message);
    }
});
