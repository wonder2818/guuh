const express = require('express');
const fs = require('fs');
const path = require('path');
const session = require('express-session');

const app = express();

app.use(session({
    secret: 'a very secret key',
    resave: false,
    saveUninitialized: true
}));
app.use(express.json());
app.use(express.static('public'));

const DB_PATH = 'database.json';

// Function to generate a random 6-character code
function generateCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

// Initialize database if it doesn't exist
if (!fs.existsSync(DB_PATH)) {
    const initialData = {
        users: {
            'owner': {
                secretCode: 'K5Y9do',
                isApproved: true,
                isAdmin: true
            }
        }
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initialData, null, 2));
}

app.post('/register', (req, res) => {
    const { name } = req.body;
    if (!name) {
        return res.status(400).json({ message: 'Name is required' });
    }

    const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));

    if (db.users[name]) {
        return res.status(400).json({ message: 'Name already taken' });
    }

    const secretCode = generateCode();
    db.users[name] = {
        secretCode,
        isApproved: false,
        isAdmin: false
    };

    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));

    res.json({ secretCode });
});

app.post('/login', (req, res) => {
    const { loginName, loginCode } = req.body;

    if (!loginName || !loginCode) {
        return res.status(400).json({ message: 'Name and secret code are required' });
    }

    const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    const user = db.users[loginName];

    if (!user || user.secretCode !== loginCode) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    if (!user.isApproved) {
        return res.status(401).json({ message: 'User not approved by admin' });
    }

    req.session.user = {
        name: loginName,
        isAdmin: user.isAdmin
    };

    res.json({ isAdmin: user.isAdmin });
});

function isAdmin(req, res, next) {
    if (req.session.user && req.session.user.isAdmin) {
        next();
    } else {
        res.status(403).json({ message: 'Forbidden' });
    }
}

app.post('/submitQuiz', (req, res) => {
    const { name, answers } = req.body;
    
    if (!name || !answers) {
        return res.status(400).json({ message: 'Name and answers are required' });
    }
    
    const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    
    if (!db.users[name]) {
        return res.status(400).json({ message: 'User not found' });
    }

    const publicCode = generateCode();
    db.users[name].answers = answers;
    db.users[name].publicCode = publicCode;

    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));

    res.json({ publicCode });
});

app.get('/users', isAdmin, (req, res) => {
    const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    const users = Object.keys(db.users).map(name => ({
        name,
        isApproved: db.users[name].isApproved,
        isAdmin: db.users[name].isAdmin
    }));
    res.json(users);
});

app.post('/approve', isAdmin, (req, res) => {
    const { name } = req.body;
    if (!name) {
        return res.status(400).json({ message: 'Name is required' });
    }

    const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    if (db.users[name]) {
        db.users[name].isApproved = true;
        fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
        res.json({ message: 'User approved' });
    } else {
        res.status(404).json({ message: 'User not found' });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

app.post('/makeAdmin', isAdmin, (req, res) => {
    const { secretCode } = req.body;
    if (!secretCode) {
        return res.status(400).json({ message: 'Secret code is required' });
    }

    const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    let foundUser = false;
    for (const name in db.users) {
        if (db.users[name].secretCode === secretCode) {
            db.users[name].isAdmin = true;
            foundUser = true;
            break;
        }
    }

    if (foundUser) {
        fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
        res.json({ message: 'User is now an admin' });
    } else {
        res.status(404).json({ message: 'User not found' });
    }
});
